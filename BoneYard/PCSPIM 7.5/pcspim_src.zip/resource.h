//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by PCSpim.rc
//
#define IDC_REMOVE                      3
#define IDD_ABOUTBOX                    100
#define ID_INDICATOR_BARE               101
#define ID_INDICATOR_DELAY_BR           102
#define ID_INDICATOR_DELAY_LD           103
#define ID_INDICATOR_REGS               104
#define IDR_MAINFRAME                   128
#define IDR_PCSPIMTYPE                  129
#define IDR_MAINFRAME_ORIG              129
#define IDD_BREAKPOINTS                 130
#define IDD_RUN                         131
#define IDD_SETTINGS                    132
#define IDD_SETVALUE                    137
#define IDD_MULTISTEP                   139
#define IDI_PCSPIMTYPE                  140
#define IDB_BITMAP1                     145
#define IDC_ADDRESS                     1000
#define IDC_ADD                         1003
#define IDC_BREAKPOINTS                 1004
#define IDC_COMMANDLINE                 1006
#define IDC_BARE                        1008
#define IDC_PSEUDO                      1009
#define IDC_QUIET                       1010
#define IDC_MAPPED                      1011
#define IDC_LOADEXCEPTION               1012
#define IDC_EXCEPTIONFILE               1013
#define IDC_BROWSE                      1014
#define IDC_DELAYEDBRANCHES             1015
#define IDC_VALUE                       1016
#define IDC_DELAYEDLOADS                1016
#define IDC_STEPS                       1017
#define IDC_COPYRIGHT                   1019
#define IDC_GENREG_HEX                  1020
#define IDC_FPREG_HEX                   1021
#define IDC_SAVEWINPOS                  1022
#define IDC_CHECK1                      1022
#define ID_FILE_SAVE_LOG                32772
#define ID_SIMULATOR_CLEAR_REGISTERS    32776
#define ID_SIMULATOR_BREAK              32785
#define ID_SIMULATOR_BREAKPOINTS        32787
#define ID_SIMULATOR_SETTINGS           32788
#define ID_SIMULATOR_SETVALUE           32789
#define ID_SIMULATOR_STEP               32790
#define ID_SIMULATOR_RELOAD             32791
#define ID_SIMULATOR_MULTISTEP          32792
#define ID_SIMULATOR_SHOWSYMBOLS        32793
#define ID_SIMULATOR_DISPLAYSYMBOLS     32794
#define ID_WINDOW_NEXT                  32796
#define ID_WINDOW_PREVIOUS              32797
#define ID_WINDOW_TILE                  32799
#define ID_SIMULATOR_REINITIALIZE       32801
#define ID_WINDOW_CLEAR_CONSOLE         32802
#define ID_WINDOW_SHOW_CONSOLE          32803
#define ID_SIMULATOR_GO                 32804
#define ID_WINDOW_MESSAGES              32805
#define ID_WINDOW_TEXTSEG               32806
#define ID_WINDOW_DATASEG               32807
#define ID_WINDOW_REGISTERS             32808
#define ID_WINDOW_CONSOLE               32809
#define ID_WINDOW_ARRANGEICONS          32810
#define ID_SIMULATOR_SETFONT            32815

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        146
#define _APS_NEXT_COMMAND_VALUE         32816
#define _APS_NEXT_CONTROL_VALUE         1023
#define _APS_NEXT_SYMED_VALUE           104
#endif
#endif
